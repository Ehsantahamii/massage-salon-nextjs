"use client"
import Loader from '@/components/module/loader/Loader'

export default function Loading() {
    return <Loader />
}