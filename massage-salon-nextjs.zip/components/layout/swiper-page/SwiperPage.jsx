import ThumbsSwiper from "@/components/module/thumbs-swiper/ThumbsSwiper";
import * as motion from "motion/react-client"
const SwiperPage = () => {
  return (
    <motion.div initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }} >
      <ThumbsSwiper />
    </motion.div>
  );
};

export default SwiperPage;
